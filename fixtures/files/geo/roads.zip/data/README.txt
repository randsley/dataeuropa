Roads sample.
