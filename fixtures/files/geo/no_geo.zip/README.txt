Nothing to map here.
